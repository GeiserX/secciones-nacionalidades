
# this is where we update / re-invent plotSPC
# https://github.com/ncss-tech/aqp/issues/59
# https://github.com/ncss-tech/aqp/issues/62
# 

# # x: SPC
# sketch <- function(x, ...) {
#   
#   
# }
# 
# # this will replace PHP-GD code in SoilWeb
# # x: SPC, single profile (SoilProfile object in aqp 2.x)
# singleProfileSketch <- function(x, moistColor=NULL, dryColor=NULL, ...) {
#   
#   
# }



