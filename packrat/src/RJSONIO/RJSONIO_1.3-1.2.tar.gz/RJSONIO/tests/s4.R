setClass("Foo",
          representation(a = "integer", b = "character"))
setClass("Bar",
          representation(a = "integer", b = "character"))
